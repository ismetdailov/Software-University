﻿using AquaShop.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Decorations.Contracts
{
    internal class Plant : Decoration
    {
        public Plant() : base(5,10.0m)
        {
            
        }
    }
}
