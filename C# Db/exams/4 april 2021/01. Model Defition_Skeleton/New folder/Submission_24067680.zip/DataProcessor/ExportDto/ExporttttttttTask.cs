﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace TeisterMask.DataProcessor.ExportDto
{
   public class ExporttttttttTask
    {
        public string TaskName { get; set; }
        public string OpenDate { get; set; }
        public string DueDate { get; set; }
        public string LabelType { get; set; }
        public string ExecutionType { get; set; }
    }
}
