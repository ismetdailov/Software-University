﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SoftJail.DataProcessor.ExportDto
{
  public  class ExportMessages
    {
        public string Description { get; set; }
    }
}
