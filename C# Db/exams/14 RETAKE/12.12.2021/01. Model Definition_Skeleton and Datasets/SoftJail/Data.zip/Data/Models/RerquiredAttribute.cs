﻿using System;

namespace SoftJail.Data.Models
{
    internal class RerquiredAttribute : Attribute
    {
    }
}