﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;

    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Serialization;
    using Data;
    using Newtonsoft.Json;
    using TeisterMask.Data.Models;
    using TeisterMask.DataProcessor.ImportDto;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedProject
            = "Successfully imported project - {0} with {1} tasks.";

        private const string SuccessfullyImportedEmployee
            = "Successfully imported employee - {0} with {1} tasks.";

        public static string ImportProjects(TeisterMaskContext context, string xmlString)
        {
            var output = new StringBuilder();
            var xmlSerializer = new XmlSerializer(
                typeof(ImportMessage[]), // ТУК НЕМОЖЕМ ДА ИЗПОЛЗВАМЕ ieNUMERUBLE И ЗАТОВА И ЗАТОВА ИЗПОЛЗВАМЕ МАСИВ
                new XmlRootAttribute("Projects"));

            var message = // ТУК ПОЛУЧАВАМЕ ДАННИТЕ
                (ImportMessage[])xmlSerializer.Deserialize(
                    new StringReader(xmlString));
            foreach (var massage in message)
            {
                if (!IsValid(massage))
                {
                    output.AppendLine("Invalid Data");
                    continue;
                }

                bool parsedDate = DateTime.TryParseExact(
                    massage.OpenDate, "dd/MM/yyyy HH",
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out var date);
                if (!parsedDate)
                {
                    output.AppendLine("Invalid Data");
                    continue;
                }
                //purchase Е МАСИВ ИЛИ КОЛЕКЦИЯ ОТ ТЕЗИ НЕЩА ДАТЕ, ТИПЕ И ТН.
                var purchase = new Project
                {
                    Name = massage.Name,
                   
                };
              //  context.EmployeesTasks.Add();
                //user не е в дадената таблица тя е свързана с card И ПО ТОЗИ НАЧИН
                //БЪРКАМЕ В ТАБЛИЦИТЕ И ВЗИМАМЕ ИМЕТО НА ЮЗЕРА ЧРЕЗ НЕГОВАТА КАРТА
              //  var username = context.Users.Where(x => x.Id == purchase.Card.UserId)
                  //  .Select(x => x.Username).FirstOrDefault();
                output.AppendLine($"Successfully imported project - {purchase.Name} with {purchase} tasks.");
            }

            context.SaveChanges();
            return output.ToString();
          //  return "TODO";
        }

        public static string ImportEmployees(TeisterMaskContext context, string jsonString)
        {
            var output = new StringBuilder();
            var employeeeee = JsonConvert
                .DeserializeObject<IEnumerable<UsersInputModel>>(jsonString);

            foreach (var employe in employeeeee)
            {
                if (!IsValid(employe) || !IsValid(employe.Username.Any()) || !IsValid(employe.Phone.Any()))
                {
                    
                    
                   
                    // Invalid data
                    output.AppendLine("Invalid Data");
                    continue;
                }
                var emplo = new Employee
                {
                    Username = employe.Username,
                    Email = employe.Email,
                    Phone = employe.Phone,

                    //EmployeesTasks = employe.Tasks.Select(x => new Task
                    // {
                    //  Id = x.
                    // }).ToList(),
                };
                    context.Employees.Add(emplo);
                output.AppendLine($"Successfully imported employee - {employe.Username} with {employe.Tasks.Count()} tasks.");
            };

            context.SaveChanges();
            return output.ToString();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}