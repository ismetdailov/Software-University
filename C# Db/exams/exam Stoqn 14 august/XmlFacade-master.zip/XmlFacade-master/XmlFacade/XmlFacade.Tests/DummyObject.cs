﻿namespace XmlFacade.Tests
{
    public class DummyObject
    {
        public string Name { get; set; }

        public int Number { get; set; }
    }
}