﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ExportDto
{
   public class ExportProject
    {

        // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
        public partial class Project
        {

            private string projectNameField;

            private string hasEndDateField;

            private ProjectTask[] tasksField;

            private byte tasksCountField;

            /// <remarks/>
            public string ProjectName
            {
                get
                {
                    return this.projectNameField;
                }
                set
                {
                    this.projectNameField = value;
                }
            }

            /// <remarks/>
            public string HasEndDate
            {
                get
                {
                    return this.hasEndDateField;
                }
                set
                {
                    this.hasEndDateField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlArrayItemAttribute("Task", IsNullable = false)]
            public ProjectTask[] Tasks
            {
                get
                {
                    return this.tasksField;
                }
                set
                {
                    this.tasksField = value;
                }
            }

            /// <remarks/>
            [System.Xml.Serialization.XmlAttributeAttribute()]
            public byte TasksCount
            {
                get
                {
                    return this.tasksCountField;
                }
                set
                {
                    this.tasksCountField = value;
                }
            }
        }

        /// <remarks/>
        [System.SerializableAttribute()]
        [System.ComponentModel.DesignerCategoryAttribute("code")]
        [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
        public partial class ProjectTask
        {

            private string nameField;

            private string labelField;

            /// <remarks/>
            public string Name
            {
                get
                {
                    return this.nameField;
                }
                set
                {
                    this.nameField = value;
                }
            }

            /// <remarks/>
            public string Label
            {
                get
                {
                    return this.labelField;
                }
                set
                {
                    this.labelField = value;
                }
            }
        }


    }
}
