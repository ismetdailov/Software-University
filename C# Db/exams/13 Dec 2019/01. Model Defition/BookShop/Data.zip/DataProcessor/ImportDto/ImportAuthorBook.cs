﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BookShop.DataProcessor.ImportDto
{

  public class ImportAuthorBook
    {
        public int? Id { get; set; }

    }
}
