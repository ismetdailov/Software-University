# XmlFacade
Simplified serialization and deserialization of xml
