﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace Artillery.DataProcessor.ExportDto
{
    [XmlType("Gun")]
   public class sadasdasdExportGuns
    {
        [XmlAttribute("Manufacturer")]
        public string Manufacturer { get; set; }


    }
}
