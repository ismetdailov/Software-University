﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.Data.Models.Enums
{
   public enum ExecutionTypeEnum
    {
        ProductBacklog, 
        SprintBacklog, 
        InProgress,
        Finished
    }
}
