﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ExportDto
{
  public  class ExportMostBusiestEmployees
    {
        public string Username { get; set; }
        public ExporttttttttTask[] Tasks { get; set; }
    }
}
