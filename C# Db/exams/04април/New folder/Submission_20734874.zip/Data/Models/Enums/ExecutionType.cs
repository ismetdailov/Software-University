﻿namespace TeisterMask.Data.Models
{
    public enum ExecutionType
    {
        ProductBacklog,
        SprintBacklog,
        InProgress,
        Finished
    }
}