﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ImportDto
{
   public class ImportTasksEmployee
    {

        public int TaskId { get; set; }
    }
}
