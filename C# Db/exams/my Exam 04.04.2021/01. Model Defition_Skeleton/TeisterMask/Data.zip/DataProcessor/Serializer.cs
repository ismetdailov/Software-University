﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Linq;
    using Data;
    using Newtonsoft.Json;
    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportProjectWithTheirTasks(TeisterMaskContext context)
        {
            var data = context.EmployeesTasks.ToList().Take(10).Where(x => context.Tasks.Count() == 0)

                // ЗА ВСЕКИ ЖАНР ВЗИМАМЕ СЛЕДНАТА ИНФОРМАЦИЯ ПО ТОЗИ НАЧИН
                .Select(x => new
                {
                    Username = x.Employee,
                    Tasks = x.Task.EmployeesTasks.Select(t => new
                    {
                        TaskName = t.Task.Name,
                        OpenDate = t.Task.OpenDate,
                        DueDate = t.Task.DueDate,
                        LabelType = t.Task.LabelType,
                        ExecutionType = t.Task.ExecutionType
                    })//.OrderByDescending(x.Task.DueDate)

                });
           //.OrderByDescending(x => x.TotalPlayers).ThenBy(x => x.Id);// СОРТИРАМЕ ПО БРОЙ ИГРАЧИ И ПО ЖАНР ИД

            return JsonConvert.SerializeObject(data, Formatting.Indented);

        }

        public static string ExportMostBusiestEmployees(TeisterMaskContext context, DateTime date)
        {
            return "TODO";

        }
    }
}