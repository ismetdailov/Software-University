﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ImportDto
{
   public class ImportTasks
    {

    }
}
