﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace TeisterMask.DataProcessor.ImportDto
{
    [XmlType("Project")] // име на таг

    public class ImportMessage
    {
        [XmlAttribute("title")] // атрибут
        [Required]
        public string Name { get; set; }

        public string OpenDate { get; set; }
        
        public string DueDate { get; set; }

        public ICollection<Task> Task { get; set; }
    }
}
