﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TeisterMask.DataProcessor.ImportDto
{
   public class UsersInputModel
    {
        [Required]
        [RegularExpression("[A-z0-9]{1,}")]
        public string Username { get; set; }
        [Required]
        
        public string Email { get; set; }

        [Required]
        [RegularExpression("[0-9]{3}-[0-9]{3}-[0-9]{4}")]
        public string Phone { get; set; }
        public IEnumerable<int> Tasks { get; set; }



    }
}
