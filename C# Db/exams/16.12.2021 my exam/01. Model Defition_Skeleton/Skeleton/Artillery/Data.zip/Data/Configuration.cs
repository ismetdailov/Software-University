﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Artillery;Trusted_Connection=True";
    }
}
